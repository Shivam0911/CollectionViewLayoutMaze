//
//  MortarViewCell.swift
//  Mortar
//
//  Created by Abraham Isaac Durán on 2/6/19.
//  Copyright © 2019 Abraham Isaac Durán. All rights reserved.
//

import UIKit

class MortarViewCell: UICollectionViewCell {
    @IBOutlet weak var pictureImageView: UIImageView!
    
}
