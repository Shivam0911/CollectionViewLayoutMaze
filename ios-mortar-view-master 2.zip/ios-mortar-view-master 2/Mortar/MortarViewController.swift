//
//  ViewController.swift
//  Mortar
//
//  Created by Abraham Isaac Durán on 2/6/19.
//  Copyright © 2019 Abraham Isaac Durán. All rights reserved.
//

import UIKit

let MORTAR_CELLS_HEIGHT: CGFloat = 120

class MortarViewController: UIViewController {
    @IBOutlet weak var collectionView: UICollectionView!
    
    var images = [UIImage]()
    var sizes = [CGSize]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.navigationController?.isNavigationBarHidden = true
        var index = 1
        while let image = UIImage(named: "\(index)") {
            images.append(image)
            index += 1
        }
        collectionView?.contentInset = UIEdgeInsets(top: 23, left: 10, bottom: 10, right: 10)

        if let layout = collectionView?.collectionViewLayout as? PinterestLayout {
            layout.delegate = self
        }

    }

}




extension MortarViewController:UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {
    
     func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return images.count
    }
    
     func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "mortar-cell", for: indexPath) as! MortarViewCell
        
        cell.pictureImageView.image = images[indexPath.row]
        
        return cell
    }
    
}

//MARK: - PINTEREST LAYOUT DELEGATE
extension MortarViewController : PinterestLayoutDelegate {
    
    // 1. Returns the photo height
    func collectionView(_ collectionView: UICollectionView, heightForPhotoAtIndexPath indexPath:IndexPath) -> CGFloat {
        return images[indexPath.item].size.height
    }
    
}
